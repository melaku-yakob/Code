<?php 
	include './config/connection.php';

$message = '';

	if(isset($_POST['login'])) {
    $userName = $_POST['user_name'];
    $password = $_POST['password'];

    $encryptedPassword = md5($password);

    $query = "select `id`, `display_name`, `user_name`, 
`profile_picture` from `users` 
where `user_name` = '$userName' and 
`password` = '$encryptedPassword';";

try {
  $stmtLogin = $con->prepare($query);
  $stmtLogin->execute();

  $count = $stmtLogin->rowCount();
  if($count == 1) {
    $row = $stmtLogin->fetch(PDO::FETCH_ASSOC);

    $_SESSION['user_id'] = $row['id'];
    $_SESSION['display_name'] = $row['display_name'];
    $_SESSION['user_name'] = $row['user_name'];
    $_SESSION['profile_picture'] = $row['profile_picture'];

    header("location: Dashboard.php");
    exit;

  } else {
    $message = 'Incorrect username or password.';
  }
}  catch(PDOException $ex) {
      echo $ex->getTraceAsString();
      echo $ex->getMessage();
      exit;
    }
  

		
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - WSU Student Clinic Patient Record  Management System</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <style>
  	
  	.login-box {
    	width: 430px;
	}
  
#system-logo {
    width: 5em !important;
    height: 5em !important;
    object-fit: cover;
    object-position: center center;
}
.login-box-msg {
  font-size: 50px;
}

.form-control {
  font-size: 22px;
}

.login-card-body {
  padding: 30px;
  margin-top: 50px;
  height: 400px;
  width: 800px;
}

.btn-block {
  font-size: 18px;
  padding: 12px 0;
}

.mb-3 {
  margin-bottom: 5px;
}
.text-center.h2.mb-0.bg-red {
  font-size: 35px; 
  color: #ffffff; 
  background-color: #0077b6; 
  padding: 0px 0px 10px 0; 
}
  </style>
</head>
<body class="hold-transition login-page  bg-brown" style="background-image: url(ck3.JPG); background-size: cover; background-position: center;">
  <div class="login-box">
    <div class="login-logo mb-4">
    </div>
    <!-- Rest of your HTML code -->
  </div>

  <!-- /.login-logo -->
  <div >
  <div class="card-body login-card-body">
  <p class="login-box-msg bg-yellow"> WSU Student Clinic Patient Record  Management System</p>
  <form method="post">
    <div class="input-group">
      <input type="text" class="form-control form-control-lg" placeholder="Username" id="user_name" name="user_name">
      <div class="input-group-append">
        <div class="input-group-text">
          
        </div>
      </div>
    </div>
    <div class="input-group mb-3">
      <input type="password" class="form-control form-control-lg rounded-0" placeholder="Password" id="password" name="password">
      <div class="input-group-append">
        <div class="input-group-text">
          
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <button name="login" type="submit" class="btn btn-primary rounded-0 btn-block">Sign In</button>
      </div>
    </div>
  </form>
</div>
          <!-- /.col -->
        </div>

        <div class="row">
          <div class="col-md-20">
            <p class="text-danger">
              <?php 
              if($message != '') {
                echo $message;
              }
              ?>
            </p>
          </div>
        </div>
      </form>

      
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->

</body>
</html>
