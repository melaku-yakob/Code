<?php 
if(!(isset($_SESSION['user_id']))) {
  header("location:index.php");
  exit;
}
?>
<aside class="main-sidebar sidebar-dark-primary bg-yellow elevation-24" style="font-size: 25px;">
    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
     
      <!-- Sidebar Menu -->
      <nav class="mt-22 ">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
         <li>
         
            <a href="dashboard.php" class="nav-link">
             
            <p style="width: 10%; color: #000000;">
          => Dashboard
           </p>
            </a>
          </li>

          
          <li class="nav-item" id="mnu_patients">
            <a href="#" class="nav-link">
              <p style="color: #000000;">            
              => Patients
              </p>
            </a>
            <ul class="nav nav-treeview bg-red  ">
              <li class="nav-item">
                <a href="new_prescription.php" class="nav-link" 
                id="mi_new_prescription">
                  <p >=> New Prescription</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="patients.php" class="nav-link" 
                id="mi_patients">               
                  <p>=> Add Patients</p>
                </a>
              </li>
             
              <li class="nav-item">
                <a href="patient_history.php" class="nav-link" 
                id="mi_patient_history">               
                  <p>=> Patient History</p>
                </a>
              </li>
              
            </ul>
          </li>



          <li class="nav-item" id="mnu_medicines ">
            <a href="#" class="nav-link">            
              <p style="color: #000000;">
              =>  Medicines              
              </p>
            </a>
            <ul class="nav nav-treeview bg-red ">
              <li class="nav-item">
                <a href="medicines.php" class="nav-link" 
                id="mi_medicines">                 
                  <p>=> Add Medicine</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="medicine_details.php" class="nav-link" 
                id="mi_medicine_details">                
                  <p>=> Medicine Details</p>
                </a>
              </li>
                            
            </ul>
          </li>


          <li class="nav-item" id="mnu_users">
            <a href="users.php" class="nav-link">          
              <p style="color: #000000;" >
              =>  Users
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="logout.php" class="nav-link">           
              <p style="color: #000000;" >
              => Logout
              </p>
            </a>
          </li>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>