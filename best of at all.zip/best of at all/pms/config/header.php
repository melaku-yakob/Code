<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-dark navbar-light fixed-top bg-yellow">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    
  </ul>
  <a href="index3.html" class="navbar-brand" style="font-size: 45px;">
    <span class="brand-text font-weight-light"> <b>WSU Student Clinic Patient Record Management System</b>  </span>
</a>
  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
    </li>
  </ul>
</nav>
<!-- /.navbar -->